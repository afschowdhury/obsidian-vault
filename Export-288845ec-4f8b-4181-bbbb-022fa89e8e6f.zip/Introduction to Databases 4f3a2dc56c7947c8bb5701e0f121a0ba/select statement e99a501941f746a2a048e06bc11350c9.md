# select statement

- the goal of the database is not only to store the data, but, we want to view the data and we can do this by SELECT statement.